--[[
--
--	Sea.data.spell
--
--	Grouped spell data
--
--	$LastChangedBy: Sinaloit $
--	$Rev: 2025 $
--	$Date: 2005-07-02 18:51:34 -0500 (Sat, 02 Jul 2005) $
--]]

Sea.data.spell = {

	--
	-- The list of desirable self-cast spells
	-- 
	selfCast = SEA_SELF_CAST_LIST;

};
