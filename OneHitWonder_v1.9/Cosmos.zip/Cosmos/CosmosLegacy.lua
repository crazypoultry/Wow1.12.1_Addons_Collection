--[[
	Cosmos Legacy
		Makes some Cosmos addons compatible with Khaos

	By: Mugendai
	Contact: mugekun@gmail.com

	This mod pretends to be Cosmos to allow some mods that support it to
	work with Khaos.  It converts the API's between the two mods using
	MCom as a compatibility layer.  This will not work for all Cosmos
	addons, just the ones that use Cosmos in basic ways.  Note that slash
	commands will not be able to update Khaos options.
	
	This is not intended as a substitute for upgrading Cosmos addons to
	properly support Khaos, but as an intermediate option until such
	addons are properly upgraded.
	
	$Id$
	$Rev$
	$LastChangedBy$
	$Date$
]]--

--------------------------------------------------
--
-- Cosmos Compatability Functions
--
--------------------------------------------------
--[[ Translate option registration ]]--
if (not Cosmos_RegisterConfiguration) then
	Cosmos_RegisterConfiguration = function (marg1, marg2, marg3, marg4, marg5, marg6, marg7, marg8, marg9, marg10, marg11, marg12, marg13, marg14)
		MCom.registerSmart( { uioption = {
			marg1, marg2, marg3, marg4, marg5, marg6, marg7, marg8, marg9, marg10, marg11, marg12, marg13, marg14
		} } );
	end;
end;

--[[ Translate slash command registration ]]--
if (not Cosmos_RegisterChatCommand) then
	Cosmos_RegisterChatCommand = function (marg1, marg2, marg3, marg4)
		MCom.registerSmart( {
			command = marg2;
			comtype = MCOM_STRINGT;
			func = marg3;
			comhelp = marg4;
		} );
	end;
end;

--[[
	Provide this function empty as it can not be used, but is expected
	by some Cosmos addons.
]]--
if (not Cosmos_UpdateValue) then
	Cosmos_UpdateValue = function () end;
end;

--[[
	Provide this function empty as it can not be used, but is expected
	by some Cosmos addons.
]]--
if (not Cosmos_SetCVar) then
	Cosmos_SetCVar = function () end;
end;

--[[
	Provide this function empty as it can not be used, but is expected
	by some Cosmos addons.
]]--
if (not CosmosMaster_DrawData) then
	CosmosMaster_DrawData = function () end;
end;