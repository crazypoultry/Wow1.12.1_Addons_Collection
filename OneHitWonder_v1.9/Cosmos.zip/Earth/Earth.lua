--[[
--
--	Earth
--
--		By Alexander Brazie
--
--]]

Earth = {
};